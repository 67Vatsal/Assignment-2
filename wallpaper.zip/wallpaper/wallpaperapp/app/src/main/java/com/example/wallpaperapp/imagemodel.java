package com.example.wallpaperapp;

public class imagemodel {

    private urlmodel src;

    public urlmodel getSrc() {
        return src;
    }

    public void setSrc(urlmodel src) {
        this.src = src;
    }

    public imagemodel(urlmodel src) {
        this.src = src;
    }
}
