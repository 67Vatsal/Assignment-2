package com.example.wallpaperapp;

public class urlmodel {

    private String portrait;

    public String getPortrait() {
        return portrait;
    }

    public void setPortrait(String portrait) {
        this.portrait = portrait;
    }

    public urlmodel(String portrait) {
        this.portrait = portrait;
    }
}
