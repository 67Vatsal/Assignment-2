package com.example.wallpaperapp;

import java.util.ArrayList;

public class Searchmodel {
    private ArrayList<imagemodel> photos;

    public Searchmodel(ArrayList<imagemodel> photos) {
        this.photos = photos;
    }

    public ArrayList<imagemodel> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<imagemodel> photos) {
        this.photos = photos;
    }
}
