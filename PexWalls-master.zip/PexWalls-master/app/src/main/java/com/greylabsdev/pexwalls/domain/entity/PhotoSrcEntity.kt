package com.greylabsdev.pexwalls.domain.entity

data class PhotoSrcEntity(
    val landscape: String,
    val large: String,
    val large2x: String,
    val medium: String,
    val original: String,
    val portrait: String,
    val small: String,
    val tiny: String,
    val byScreenResolutionUrl: String
)
