package com.greylabsdev.pexwalls.presentation.collection

enum class UpdaterType {
    SEARCH, CATEGORY, CURATED, FAVORITES
}
